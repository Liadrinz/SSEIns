/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.monkey.backends1;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ahuan
 */
@Entity
@Table(name = "filesse")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Filesse.findAll", query = "SELECT f FROM Filesse f")
    , @NamedQuery(name = "Filesse.findByFId", query = "SELECT f FROM Filesse f WHERE f.fId = :fId")
    , @NamedQuery(name = "Filesse.findByUrl", query = "SELECT f FROM Filesse f WHERE f.url = :url")
    , @NamedQuery(name = "Filesse.findByType", query = "SELECT f FROM Filesse f WHERE f.type = :type")})
public class Filesse implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "fId")
    private Integer fId;
    @Size(max = 256)
    @Column(name = "url")
    private String url;
    @Size(max = 16)
    @Column(name = "type")
    private String type;
    @JoinColumn(name = "albId", referencedColumnName = "albId")
    @ManyToOne
    private Album albId;
    @JoinColumn(name = "nId", referencedColumnName = "nId")
    @ManyToOne
    private Notice nId;
    @JoinColumn(name = "sId", referencedColumnName = "sId")
    @ManyToOne
    private Student sId;
    @OneToMany(mappedBy = "fId")
    private Collection<Student> studentCollection;

    public Filesse() {
    }

    public Filesse(Integer fId) {
        this.fId = fId;
    }

    public Integer getFId() {
        return fId;
    }

    public void setFId(Integer fId) {
        this.fId = fId;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Album getAlbId() {
        return albId;
    }

    public void setAlbId(Album albId) {
        this.albId = albId;
    }

    public Notice getNId() {
        return nId;
    }

    public void setNId(Notice nId) {
        this.nId = nId;
    }

    public Student getSId() {
        return sId;
    }

    public void setSId(Student sId) {
        this.sId = sId;
    }

    @XmlTransient
    public Collection<Student> getStudentCollection() {
        return studentCollection;
    }

    public void setStudentCollection(Collection<Student> studentCollection) {
        this.studentCollection = studentCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (fId != null ? fId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Filesse)) {
            return false;
        }
        Filesse other = (Filesse) object;
        if ((this.fId == null && other.fId != null) || (this.fId != null && !this.fId.equals(other.fId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.monkey.backends1.Filesse[ fId=" + fId + " ]";
    }
    
}
