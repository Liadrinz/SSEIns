/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.monkey.backends1;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ahuan
 */
@Entity
@Table(name = "notice")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Notice.findAll", query = "SELECT n FROM Notice n")
    , @NamedQuery(name = "Notice.findByNId", query = "SELECT n FROM Notice n WHERE n.nId = :nId")})
public class Notice implements Serializable {

    private static final long serialVersionUID = 1L;
    @Lob
    @Size(max = 65535)
    @Column(name = "text")
    private String text;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "nId")
    private Integer nId;
    @JoinTable(name = "belongs", joinColumns = {
        @JoinColumn(name = "nId", referencedColumnName = "nId")}, inverseJoinColumns = {
        @JoinColumn(name = "kId", referencedColumnName = "kId")})
    @ManyToMany
    private Collection<Klass> klassCollection;
    @OneToMany(mappedBy = "nId")
    private Collection<Filesse> filesseCollection;
    @OneToMany(mappedBy = "nId")
    private Collection<Comment> commentCollection;

    public Notice() {
    }

    public Notice(Integer nId) {
        this.nId = nId;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Integer getNId() {
        return nId;
    }

    public void setNId(Integer nId) {
        this.nId = nId;
    }

    @XmlTransient
    public Collection<Klass> getKlassCollection() {
        return klassCollection;
    }

    public void setKlassCollection(Collection<Klass> klassCollection) {
        this.klassCollection = klassCollection;
    }

    @XmlTransient
    public Collection<Filesse> getFilesseCollection() {
        return filesseCollection;
    }

    public void setFilesseCollection(Collection<Filesse> filesseCollection) {
        this.filesseCollection = filesseCollection;
    }

    @XmlTransient
    public Collection<Comment> getCommentCollection() {
        return commentCollection;
    }

    public void setCommentCollection(Collection<Comment> commentCollection) {
        this.commentCollection = commentCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (nId != null ? nId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Notice)) {
            return false;
        }
        Notice other = (Notice) object;
        if ((this.nId == null && other.nId != null) || (this.nId != null && !this.nId.equals(other.nId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.monkey.backends1.Notice[ nId=" + nId + " ]";
    }
    
}
